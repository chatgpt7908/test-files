#!/bin/bash

# SSL Certificate Generation for Production ONLY (Reverse Proxy)
# Run this ONCE from /root/sachin/production/
# Creates SSL for ALL subdomains (*.sachin.com)

echo "🔐 Generating SSL Certificate for Production..."
echo "   This will be used by Reverse Proxy ONLY"
echo ""

# Create ssl directory
mkdir -p ../ssl

# Generate wildcard certificate
openssl req -x509 -nodes -days 365 -newkey rsa:2048 \
  -keyout ../ssl/selfsigned.key \
  -out ../ssl/selfsigned.crt \
  -subj "/C=IN/ST=Maharashtra/L=Mumbai/O=Sachin Organization/CN=*.sachin.com"

# Set permissions
chmod 644 ../ssl/selfsigned.crt
chmod 644 ../ssl/selfsigned.key

echo "✅ SSL Certificate Generated!"
echo ""
echo "📂 Location: /root/sachin/ssl/"
echo "   - Certificate: ../ssl/selfsigned.crt"
echo "   - Private Key: ../ssl/selfsigned.key"
echo ""
echo "🔒 Certificate Details:"
echo "   - Domain: *.sachin.com (wildcard)"
echo "   - Valid for: 365 days"
echo ""
echo "📌 Usage: Reverse Proxy ONLY"
echo ""
echo "✨ Done! Now run:"
echo "   cd /root/sachin/reverse-proxy"
echo "   docker-compose -f docker-compose-reverse-proxy.yml up -d"

